#ifndef ModbusBits_h
#define ModbusBits_h

bool getBit(byte* area, int index)
{
	unsigned short stidx = index / 8;
	return bitRead(area[stidx], index%8);
}

void setBit(byte* area, int index, bool value)
{
	unsigned short stidx = index / 8;
	bitWrite(area[stidx], index%8, value);
}

#endif
