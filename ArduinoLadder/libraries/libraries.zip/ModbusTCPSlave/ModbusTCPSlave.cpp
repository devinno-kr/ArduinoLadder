#include "ModbusTCPSlave.h"

ModbusTCPSlave::ModbusTCPSlave()
{
  this->server = new EthernetServer(502);
  
  words = new LinkedList<ModbusTCPSlaveWordAddress*>(); 
  bits = new LinkedList<ModbusTCPSlaveBitAddress*>(); 
}

void ModbusTCPSlave::begin(byte slave)
{
	this->slave = slave;

	server->begin();
 
	ResCnt=0;		
}

bool ModbusTCPSlave::addWordArea(unsigned short Address, unsigned short* values, int cnt)
{
	if(getWordAddress(Address)==NULL)
	{
		words->add(new ModbusTCPSlaveWordAddress(Address, values, cnt));
		return true;
	}
	return false;
}

bool ModbusTCPSlave::addBitArea(unsigned short Address, byte* values, int cnt)
{
	if(getBitAddress(Address)==NULL)
	{
		bits->add(new ModbusTCPSlaveBitAddress(Address, values, cnt));
		return true;
	}
	return false;
}

void ModbusTCPSlave::loop()
{
	EthernetClient client = server->available();
	if (client) 
	{
		if (!isConnected) 
		{
			client.flush();
			isConnected = true;
		}

		bool bvalid = true;
		while(client.available()) 
		{
			byte d = client.read();
			lstResponse[ResCnt++]=d;
			lastrecv = millis();
		}

		if(ResCnt >= 10)
		{
			byte Slave = lstResponse[6];
			if(Slave == slave)
			{
				byte Func = lstResponse[7];
				int StartAddress = (lstResponse[8] << 8) | lstResponse[9];

				switch(Func)
				{
					case 1:
					case 2:
						if(ResCnt == 12)
						{
							unsigned short Length = (lstResponse[10] << 8) | lstResponse[11];
							ModbusTCPSlaveBitAddress *a = getBitAddress(StartAddress, Length);

							if (Length > 0 && a != NULL)
							{
								unsigned short stidx = (StartAddress - a->addr) / 8;
								unsigned short nlen = ((Length-1) / 8)+1;

								byte dat[nlen];
								memset(dat,0,nlen);

								int ng=(StartAddress - a->addr) % 8;
								int ns=stidx;
								for(int i=0;i<nlen;i++)
								{
									byte val=0;
									for(int j=0;j<8;j++)
									{
										if(bitRead(a->values[ns], ng++)) bitSet(val,j);
										if(ng==8){ns++;ng=0;}
									}
									dat[i]=val;
								}
								
								byte ret[9+nlen];
								ret[0] = 0;
								ret[1] = 0;
								ret[2] = 0;
								ret[3] = 0;
								ret[4] = (byte)(((nlen + 3) & 0xFF00) >> 8);
								ret[5] = (byte)(((nlen + 3) & 0x00FF));
								ret[6] = Slave;
								ret[7] = Func;
								ret[8] = nlen;
								for(int i=0;i<nlen;i++) ret[9+i]=dat[i];
								
								client.write(ret, 9+nlen);

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 3:
					case 4:
						if(ResCnt == 12)
						{
							unsigned short Length = (lstResponse[10] << 8) | lstResponse[11];
							ModbusTCPSlaveWordAddress *a = getWordAddress(StartAddress, Length);

							if (Length > 0 && a != NULL)
							{
								unsigned short stidx = StartAddress - a->addr;
								unsigned short nlen = Length * 2;

								byte ret[9+nlen];
								ret[0] = 0;
								ret[1] = 0;
								ret[2] = 0;
								ret[3] = 0;
								ret[4] = (byte)(((nlen + 3) & 0xFF00) >> 8);
								ret[5] = (byte)(((nlen + 3) & 0x00FF));
								ret[6] = Slave;
								ret[7] = Func;
								ret[8] = nlen;
								for(int i=stidx;i<stidx+Length;i++)
								{
									ret[9+((i-stidx)*2)+0]=((a->values[i] & 0xFF00) >> 8);
									ret[9+((i-stidx)*2)+1]=((a->values[i] & 0xFF));
								}
								
								client.write(ret, 9+nlen);

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 5:
						if(ResCnt == 12)
						{
							unsigned short Data = (lstResponse[10] << 8) | lstResponse[11];
							ModbusTCPSlaveBitAddress *a = getBitAddress(StartAddress);

							if (a != NULL)
							{
								unsigned short stidx = (StartAddress - a->addr) / 8;
								bitWrite(a->values[stidx], (StartAddress - a->addr) % 8, Data == 0xFF00);

								byte ret[12];
								ret[0] = 0;
								ret[1] = 0;
								ret[2] = 0;
								ret[3] = 0;
								ret[4] = 0;
								ret[5] = 6;
								ret[6] = Slave;
								ret[7] = Func;
								ret[8] = (StartAddress & 0xFF00) >> 8;
								ret[9] = (StartAddress & 0x00FF);
								ret[10] = (Data & 0xFF00) >> 8;
								ret[11] = (Data & 0x00FF);

								client.write(ret, 12);

								ResCnt=0;
							}
						}
						break;
					case 6:
						if(ResCnt == 12)
						{
							unsigned short Data = (lstResponse[10] << 8) | lstResponse[11];
							ModbusTCPSlaveWordAddress *a = getWordAddress(StartAddress);

							if (a != NULL)
							{
								unsigned short stidx = StartAddress - a->addr;
								a->values[stidx] = Data;

								byte ret[12];
								ret[0] = 0;
								ret[1] = 0;
								ret[2] = 0;
								ret[3] = 0;
								ret[4] = 0;
								ret[5] = 6;
								ret[6] = Slave;
								ret[7] = Func;
								ret[8] = (StartAddress & 0xFF00) >> 8;
								ret[9] = (StartAddress & 0x00FF);
								ret[10] = (Data & 0xFF00) >> 8;
								ret[11] = (Data & 0x00FF);

								client.write(ret, 12);

								ResCnt=0;
							}
						}
						break;
					case 15:
						if(ResCnt >= 13)
						{
							unsigned short Length = (lstResponse[10] << 8) | lstResponse[11];
							unsigned short ByteCount = lstResponse[12];
							if(ResCnt >= 13 + ByteCount)
							{
								ModbusTCPSlaveBitAddress *a = getBitAddress(StartAddress, Length);
								if (a != NULL) 
								{
									unsigned short stidx = (StartAddress - a->addr) / 8;
									int ng = (StartAddress - a->addr) % 8;
									int ns = stidx;

									for(int i=13; i<13+ByteCount; i++)
									{
										byte val = lstResponse[i];
										for(int j=0; j<8; j++)
										{
											bitWrite(a->values[ns], ng++, bitRead(val,j));
											if(ng == 8) { ns++; ng=0; }
										}
									}

									if(bvalid)
									{
										byte ret[12];
										ret[0] = 0;
										ret[1] = 0;
										ret[2] = 0;
										ret[3] = 0;
										ret[4] = 0;
										ret[5] = 6;
										ret[6] = Slave;
										ret[7] = Func;
										ret[8] = (StartAddress & 0xFF00) >> 8;
										ret[9] = (StartAddress & 0x00FF);
										ret[10] = (Length & 0xFF00) >> 8;
										ret[11] = (Length & 0x00FF);

										client.write(ret, 12); 

										ResCnt=0;
									}
								}
								else bvalid = false;
							}
						}
						break;
					case 16:
						if(ResCnt >= 13)
						{
							unsigned short Length = (lstResponse[10] << 8) | lstResponse[11];
							unsigned short ByteCount = lstResponse[12];
							if(ResCnt >= 13 + ByteCount)
							{
								ModbusTCPSlaveWordAddress *a = getWordAddress(StartAddress);
								if (a != NULL) 
								{
									for(int i=13; i<13 + ByteCount; i+=2)
									{
										unsigned short data = lstResponse[i] << 8 | lstResponse[i+1];
										if ((StartAddress + ((i-13)/2)) - a->addr < a->len) 
											a->values[(StartAddress + ((i-13)/2)) - a->addr] = data;	
										else { bvalid=false; break; }
									}

									if(bvalid)
									{
										byte ret[12];
										ret[0] = 0;
										ret[1] = 0;
										ret[2] = 0;
										ret[3] = 0;
										ret[4] = 0;
										ret[5] = 6;
										ret[6] = Slave;
										ret[7] = Func;
										ret[8] = (StartAddress & 0xFF00) >> 8;
										ret[9] = (StartAddress & 0x00FF);
										ret[10] = (Length & 0xFF00) >> 8;
										ret[11] = (Length & 0x00FF);

										client.write(ret, 12); 

										ResCnt=0;
									}
								}
								else bvalid = false;
							}
							else bvalid = false;
						}
						break;
					case 26:
						if(ResCnt >= 13)
						{
							unsigned short Data = (lstResponse[11] << 8) | lstResponse[12];
							ModbusTCPSlaveWordAddress *a = getWordAddress(StartAddress);
							if (a != NULL)
							{
								unsigned short stidx = StartAddress - a->addr;
								unsigned short bitidx = lstResponse[10];

								if(bitidx >= 0 && bitidx < 16)
								{
									bitWrite(a->values[stidx], bitidx, Data==0xFF00);
 
									byte ret[12];
									ret[0] = 0;
									ret[1] = 0;
									ret[2] = 0;
									ret[3] = 0;
									ret[4] = 0;
									ret[5] = 6;
									ret[6] = Slave;
									ret[7] = Func;
									ret[8] = (StartAddress & 0xFF00) >> 8;
									ret[9] = (StartAddress & 0x00FF);
									ret[10] = (a->values[stidx]&0xFF00) >> 8;
									ret[11] = (a->values[stidx]&0x00FF);

									client.write(ret, 12); 

									ResCnt=0;
								}
								else bvalid = false;
							}
							else bvalid = false;
						}
						break;
				}
			}
		}

		if(!bvalid && ResCnt > 0) ResCnt = 0;
		if(ResCnt > 0 && (millis() - lastrecv > 50 || millis() < lastrecv)) ResCnt = 0;
	}
}

ModbusTCPSlaveWordAddress* ModbusTCPSlave::getWordAddress(unsigned short Addr)
{
	ModbusTCPSlaveWordAddress* ret=NULL;
	for(int i = 0; i < words->size(); i++)
	{
		ModbusTCPSlaveWordAddress* a = words->get(i);
		if(a!=NULL && Addr >= a->addr && Addr < a->addr + a->len) ret=a;
	}
	return ret;
}

ModbusTCPSlaveBitAddress* ModbusTCPSlave::getBitAddress(unsigned short Addr)
{
	ModbusTCPSlaveBitAddress* ret=NULL;
	for(int i = 0; i < bits->size(); i++)
	{
		ModbusTCPSlaveBitAddress* a = bits->get(i);
		if(a!=NULL && Addr >= a->addr && Addr < a->addr + (a->len*8)) ret=a;
	}
	return ret;
}

ModbusTCPSlaveWordAddress* ModbusTCPSlave::getWordAddress(unsigned short Addr, unsigned short Len)
{
	ModbusTCPSlaveWordAddress* ret=NULL;
	for(int i = 0; i < words->size(); i++)
	{
		ModbusTCPSlaveWordAddress* a = words->get(i);
		if(a!=NULL && Addr >= a->addr && Addr+Len <= a->addr + a->len) ret=a;
	}
	return ret;
}

ModbusTCPSlaveBitAddress* ModbusTCPSlave::getBitAddress(unsigned short Addr, unsigned short Len)
{
	ModbusTCPSlaveBitAddress* ret=NULL;
	for(int i = 0; i < bits->size(); i++)
	{
		ModbusTCPSlaveBitAddress* a = bits->get(i);
		if(a!=NULL && Addr >= a->addr && Addr+Len <= a->addr + (a->len*8)) ret=a;
	}
	return ret;
}
 


ModbusTCPSlaveBitAddress::ModbusTCPSlaveBitAddress(unsigned short Address, byte* value, int cnt)
{
	addr = Address;
	values = value;
	len = cnt;
}

ModbusTCPSlaveWordAddress::ModbusTCPSlaveWordAddress(unsigned short Address, unsigned short* value, int cnt)
{
	addr = Address;
	values = value;
	len = cnt;
}
