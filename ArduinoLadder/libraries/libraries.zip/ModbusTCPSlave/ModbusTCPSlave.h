#ifndef _MODBUS_TCP_SLAVE_H
#define _MODBUS_TCP_SLAVE_H

#include "Arduino.h"
#include "Ethernet.h"
#include "utility/LinkedList.h"

#define _ListSize 300

class ModbusTCPSlaveWordAddress
{
	public : 
		unsigned short addr;
		int len;
		unsigned short *values;
		ModbusTCPSlaveWordAddress(unsigned short Address, unsigned short* value, int cnt);
};

class ModbusTCPSlaveBitAddress
{
	public : 
		unsigned short addr;
		int len;
		byte *values;
		ModbusTCPSlaveBitAddress(unsigned short Address, byte* value, int cnt);
};

class ModbusTCPSlave
{
	public : 
		ModbusTCPSlave();
		void begin(byte slave);
		bool addWordArea(unsigned short Address, unsigned short* values, int cnt);
		bool addBitArea(unsigned short Address, byte* values, int cnt);
		void loop();

	private:
		byte slave;
		EthernetServer *server;
		LinkedList<ModbusTCPSlaveWordAddress*>  *words;
		LinkedList<ModbusTCPSlaveBitAddress*>  *bits;
		ModbusTCPSlaveWordAddress* getWordAddress(unsigned short Addr);
		ModbusTCPSlaveBitAddress* getBitAddress(unsigned short Addr);
		ModbusTCPSlaveWordAddress* getWordAddress(unsigned short Addr,unsigned short Len);
		ModbusTCPSlaveBitAddress* getBitAddress(unsigned short Addr,unsigned short Len);
		byte lstResponse[_ListSize];

		int ResCnt=0;
		unsigned long lastrecv;
		bool isConnected;
};

#endif