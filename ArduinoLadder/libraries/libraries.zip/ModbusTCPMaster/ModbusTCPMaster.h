#ifndef _MODBUS_TCP_MASTER_H
#define _MODBUS_TCP_MASTER_H

#include "Ethernet.h"

class ModbusTCPMaster
{
    public:
        ModbusTCPMaster()																		{   bufSize = 512;						buf = (byte*)malloc(bufSize);	}
        ModbusTCPMaster(long bufferSize)														{   bufSize = bufferSize;				buf = (byte*)malloc(bufSize);	}

        void begin(IPAddress ip, unsigned short connectionTimeout = 100)																
		{	
			client = new EthernetClient();		
			this->ip = ip;		
			client->setConnectionTimeout(connectionTimeout);		
		}
        void end()																				{	client->stop();														}
		void setTimeout(int timeout)															{	this->timeout = timeout; 											}

		bool bitRead_F1(byte slave, int startAddr, int length, bool* data)						{   return bitRead_Fn(1, slave, startAddr, length, data);				}
        bool bitRead_F2(byte slave, int startAddr, int length, bool* data)						{   return bitRead_Fn(2, slave, startAddr, length, data);				}
        bool wordRead_F3(byte slave, int startAddr, int length, unsigned short* data)			{   return wordRead_Fn(3, slave, startAddr, length, data);				}
        bool wordRead_F4(byte slave, int startAddr, int length, unsigned short* data)			{   return wordRead_Fn(4, slave, startAddr, length, data);				}
        bool bitWrite_F5(byte slave, int startAddr, bool value)                     
        {
            bool ret = false;
            int resCnt = 12;
            int val = value ? 0xFF00 : 0x0000;
            
            byte sbuf[12];
			sbuf[0] = 0;
			sbuf[1] = 0;
			sbuf[2] = 0;
			sbuf[3] = 0;
			sbuf[4] = 0x00;
			sbuf[5] = 0x06;
            sbuf[6] = slave;
            sbuf[7] = 0x05;
            sbuf[8] = ((startAddr & 0xFF00) >> 8);
            sbuf[9] = ((startAddr & 0x00FF));
            sbuf[10] = ((val & 0xFF00) >> 8);
            sbuf[11] = ((val & 0x00FF));

            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);

            if(SendRecv(sbuf, 12, rbuf, resCnt))     ret=true;                
                        
            return ret;
        }
        bool wordWrite_F6(byte slave, int startAddr, unsigned short value)                     
        {
            bool ret = false;
            int resCnt = 12;
            
            byte sbuf[12];
			sbuf[0] = 0;
			sbuf[1] = 0;
			sbuf[2] = 0;
			sbuf[3] = 0;
			sbuf[4] = 0x00;
			sbuf[5] = 0x06;
            sbuf[6] = slave;
            sbuf[7] = 0x06;
            sbuf[8] = ((startAddr & 0xFF00) >> 8);
            sbuf[9] = ((startAddr & 0x00FF));
            sbuf[10] = ((value & 0xFF00) >> 8);
            sbuf[11] = ((value & 0x00FF));
            
            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);

            if(SendRecv(sbuf, 12, rbuf, resCnt))     ret=true;                
                        
            return ret;
        }
        
        bool multiBitWrite_F15(byte slave, int startAddr, bool* values, int vlen)
        {
            bool ret = false;
            int resCnt = 12;
            int len = vlen / 8;
            len += (vlen % 8 == 0) ? 0 : 1;

			int vlenEx = len + 0x07;

            byte sbuf[13 + len];
			sbuf[0] = 0;
            sbuf[1] = 0;
            sbuf[2] = 0;
            sbuf[3] = 0;
            sbuf[4] = ((vlenEx & 0xFF00) >> 8);
            sbuf[5] = ((vlenEx & 0x00FF));
            sbuf[6] = slave;
            sbuf[7] = 0x0F;
            sbuf[8] = ((startAddr & 0xFF00) >> 8);
            sbuf[9] = ((startAddr & 0x00FF));
            sbuf[10] = ((vlen & 0xFF00) >> 8);
            sbuf[11] = ((vlen & 0x00FF));
            sbuf[12] = len;

            for(int i = 0; i < len; i++)
            {
                byte val = 0;
                for(int j = i * 8, k=0; j < vlen && j < (i * 8) + 8; j++, k++)
                {
                    bitWrite(val, k, values[j]);
                }
                sbuf[13 + i] = val;
            }
            
            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);
            if(SendRecv(sbuf, 13+len, rbuf, resCnt))     ret=true;                
            
            return ret;
        }

        bool multiWordWrite_F16(byte slave, int startAddr, unsigned short* values, int vlen)
        {
            bool ret = false;
            int resCnt = 12;
            
			int vlenEx = vlen * 2 + 0x07;

            byte sbuf[9 + (vlen * 2)];
			sbuf[0] = 0;
            sbuf[1] = 0;
            sbuf[2] = 0;
            sbuf[3] = 0;
            sbuf[4] = ((vlenEx & 0xFF00) >> 8);
            sbuf[5] = ((vlenEx & 0x00FF));
            sbuf[6] = slave;
            sbuf[7] = 0x10;
            sbuf[8] = ((startAddr & 0xFF00) >> 8);
            sbuf[9] = ((startAddr & 0x00FF));
            sbuf[10] = ((vlen & 0xFF00) >> 8);
            sbuf[11] = ((vlen & 0x00FF));
            sbuf[12] = vlen * 2;
            
			for(int i = 0; i < vlen; i++)
            {
                sbuf[13 + (i * 2)] = (values[i] & 0xFF00) >> 8;
                sbuf[14 + (i * 2)] = (values[i] & 0x00FF);
            }
            
            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);
            if(SendRecv(sbuf, 13+(vlen*2), rbuf, resCnt))     ret=true;                
                        
            return ret;
        }

     private: 
		unsigned long prev = 0;
        byte* buf;
        long bufSize;
        int timeout = 200;
		IPAddress ip;
        EthernetClient* client;
	    
		bool bitRead_Fn(byte fn, byte slave, int startAddr, int length, bool* data)
        {
            bool ret = false;

            int resCnt = length / 8;
            if (length % 8 != 0) resCnt++;
			resCnt += 9;

            byte sbuf[12];
			sbuf[0] = 0;
			sbuf[1] = 0;
			sbuf[2] = 0;
			sbuf[3] = 0;
			sbuf[4] = 0x00;
			sbuf[5] = 0x06;
			sbuf[6] = slave;
			sbuf[7] = fn;
			sbuf[8] = ((startAddr & 0xFF00) >> 8);
			sbuf[9] = ((startAddr & 0x00FF));
			sbuf[10] = ((length & 0xFF00) >> 8);
			sbuf[11] = ((length & 0x00FF));
             
            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);

            if(SendRecv(sbuf, 12, rbuf, resCnt))
            {
                for(int i=0;i<length;i++)
                {
                    int midx = i / 8, bidx = i % 8; 
                    data[i] = bitRead(rbuf[9 + midx], bidx);
                }
                ret=true;                
            }
            
            return ret;
        }

        bool wordRead_Fn(byte fn, byte slave, int startAddr, int length, unsigned short* data)
        {
            bool ret = false;

            int resCnt = length * 2 + 9;

            byte sbuf[12];
			sbuf[0] = 0;
			sbuf[1] = 0;
			sbuf[2] = 0;
			sbuf[3] = 0;
			sbuf[4] = 0x00;
			sbuf[5] = 0x06;
            sbuf[6] = slave;
            sbuf[7] = fn;
            sbuf[8] = ((startAddr & 0xFF00) >> 8);
            sbuf[9] = ((startAddr & 0x00FF));
            sbuf[10] = ((length & 0xFF00) >> 8);
            sbuf[11] = ((length & 0x00FF));

            byte rbuf[resCnt];
            memset(rbuf, 0, resCnt);

            if(SendRecv(sbuf, 12, rbuf, resCnt))
            {
                for(int i=0;i<length;i++)
                {
                    data[i] = ((unsigned short)buf[9+(i*2)] << 8) | ((unsigned short)buf[10+(i*2)]);
                }
                ret=true;                
            }
            
            return ret;
        }
	 
		bool SendRecv(byte* sendbuf, int len_sendbuf, byte* recvbuf, int len_recvbuf)
        {
            bool ret=false;
           
			if(!client->connected()) client->connect(ip, 502);

			if(client->connected()) 
			{
				for(int i=0;i<len_sendbuf;i++) client->write(sendbuf[i]);
				client->flush();
				 
				unsigned long prev = millis();
				unsigned long gap=0;
				bool bValid = true;
				long nCnt = 0;

				while (true)
				{
					while(client->available())
					{
						byte v = client->read();
						if(nCnt < len_recvbuf && nCnt < bufSize) buf[nCnt++] = v; 
						else bValid = false;
					}
					gap = millis() - prev;
					if (gap >= timeout) break;
					if (nCnt == len_recvbuf) break;
				}

				if (gap < timeout && bValid)
				{
					memcpy(recvbuf, buf, len_recvbuf);
					ret = true;
				}
			}

			if(!client->connected()) client->stop();

            return ret;
        }

};


#endif