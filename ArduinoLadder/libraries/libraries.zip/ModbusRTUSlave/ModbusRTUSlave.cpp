#include "ModbusRTUSlave.h"

#define VSET	false
#define VRESET	true

ModbusRTUSlave::ModbusRTUSlave(HardwareSerial& serialport) 
{
  ser = &serialport;
  
  words = new LinkedList<ModbusRTUSlaveWordAddress*>(); 
  bits = new LinkedList<ModbusRTUSlaveBitAddress*>(); 
}

void ModbusRTUSlave::begin(byte slaveAddress, unsigned long baudrate) 
{
	slave = slaveAddress;

	ser->begin(baudrate);
	ResCnt=0;		
}

bool ModbusRTUSlave::addWordArea(unsigned short Address, unsigned short* values, int cnt)
{
	if(getWordAddress(Address)==NULL)
	{
		words->add(new ModbusRTUSlaveWordAddress(Address, values, cnt));
		return true;
	}
	return false;
}

bool ModbusRTUSlave::addBitArea(unsigned short Address, byte* values, int cnt)
{
	if(getBitAddress(Address)==NULL)
	{
		bits->add(new ModbusRTUSlaveBitAddress(Address, values, cnt));
		return true;
	}
	return false;
}

ModbusRTUSlaveWordAddress* ModbusRTUSlave::getWordAddress(unsigned short Addr)
{
	ModbusRTUSlaveWordAddress* ret=NULL;
	for(int i = 0; i < words->size(); i++)
	{
		ModbusRTUSlaveWordAddress* a = words->get(i);
		if(a!=NULL && Addr >= a->addr && Addr < a->addr + a->len) ret=a;
	}
	return ret;
}
ModbusRTUSlaveBitAddress* ModbusRTUSlave::getBitAddress(unsigned short Addr)
{
	ModbusRTUSlaveBitAddress* ret=NULL;
	for(int i = 0; i < bits->size(); i++)
	{
		ModbusRTUSlaveBitAddress* a = bits->get(i);
		if(a!=NULL && Addr >= a->addr && Addr < a->addr + (a->len*8)) ret=a;
	}
	return ret;
}

ModbusRTUSlaveWordAddress* ModbusRTUSlave::getWordAddress(unsigned short Addr, unsigned short Len)
{
	ModbusRTUSlaveWordAddress* ret=NULL;
	for(int i = 0; i < words->size(); i++)
	{
		ModbusRTUSlaveWordAddress* a = words->get(i);
		if(a!=NULL && Addr >= a->addr && Addr+Len <= a->addr + a->len) ret=a;
	}
	return ret;
}
ModbusRTUSlaveBitAddress* ModbusRTUSlave::getBitAddress(unsigned short Addr, unsigned short Len)
{
	ModbusRTUSlaveBitAddress* ret=NULL;
	for(int i = 0; i < bits->size(); i++)
	{
		ModbusRTUSlaveBitAddress* a = bits->get(i);
		if(a!=NULL && Addr >= a->addr && Addr+Len <= a->addr + (a->len*8)) ret=a;
	}
	return ret;
}

void ModbusRTUSlave::setRTS(bool use, int pinNumber, int prevDelay, int nextDelay)
{
	useRTS = use;
	pinRTS = pinNumber;
	pDelay = prevDelay;
	nDelay = nextDelay;

	if(useRTS) pinMode(pinNumber, OUTPUT);
	digitalWrite(pinNumber, VRESET);
}

void ModbusRTUSlave::setBroadcast(bool broadcast)
{
	useBroadcast = broadcast;
}

void ModbusRTUSlave::loop()
{
	bool bvalid = true;
	while(ser->available()) 
	{
		byte d = ser->read();
		lstResponse[ResCnt++]=d;
		if(ResCnt>=4)
		{
			byte Slave = lstResponse[0];
			if(Slave == slave || (useBroadcast && Slave == 0))
			{
				byte Function = lstResponse[1];
	            		unsigned short Address = (lstResponse[2] << 8) | lstResponse[3];
				switch(Function)
				{
					case 1:		//BitRead
					case 2:
						if(ResCnt >= 8 && !(useBroadcast && Slave == 0))
						{
							unsigned short Length = (lstResponse[4] << 8) | lstResponse[5];
							byte hi = 0xFF, lo = 0xFF;
							getCRC(lstResponse,_ListSize, 0, 6, &hi, &lo);
							ModbusRTUSlaveBitAddress *a = getBitAddress(Address, Length);
							if (Length > 0 && a != NULL && lstResponse[6] == hi && lstResponse[7] == lo)
							{
								unsigned short stidx = (Address - a->addr) / 8;
								unsigned short nlen = ((Length-1) / 8)+1;

								byte dat[nlen];
								memset(dat,0,nlen);

								int ng=(Address - a->addr) % 8;
								int ns=stidx;
								for(int i=0;i<nlen;i++)
								{
									byte val=0;
									for(int j=0;j<8;j++)
									{
										if(bitRead(a->values[ns], ng++)) bitSet(val,j);
										if(ng==8){ns++;ng=0;}
									}
									dat[i]=val;
								}
								
								byte ret[3+nlen+2];
								ret[0]=Slave;
								ret[1]=Function;
								ret[2]=nlen;
								for(int i=0;i<nlen;i++) ret[3+i]=dat[i];
  							    byte hi = 0xFF, lo = 0xFF;
								getCRC(ret, 3+nlen+2, 0, 3+nlen, &hi, &lo);
								ret[3+nlen]=hi;
								ret[3+nlen+1]=lo;

								if(useRTS) 
								{
									digitalWrite(pinRTS, VSET);
									delay(pDelay);
								}
								ser->write(ret, 3+nlen+2);
								if(useRTS) 
								{
									delay(nDelay);
									digitalWrite(pinRTS, VRESET);
								}

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 3:		//WordRead	
					case 4:
						if(ResCnt >= 8 && !(useBroadcast && Slave == 0))
						{
							unsigned short Length = (lstResponse[4] << 8) | lstResponse[5];
							byte hi = 0xFF, lo = 0xFF;
							getCRC(lstResponse,_ListSize, 0, 6, &hi, &lo);
							ModbusRTUSlaveWordAddress *a = getWordAddress(Address, Length);
							if (Length > 0 && a != NULL && lstResponse[6] == hi && lstResponse[7] == lo)
							{
								unsigned short stidx = Address - a->addr;
								unsigned short nlen = Length * 2;

								byte ret[3+nlen+2];
								ret[0]=Slave;
								ret[1]=Function;
								ret[2]=nlen;
								for(int i=stidx;i<stidx+Length;i++)
								{
									ret[3+((i-stidx)*2)+0]=((a->values[i] & 0xFF00) >> 8);
									ret[3+((i-stidx)*2)+1]=((a->values[i] & 0xFF));
								}
  							    byte hi = 0xFF, lo = 0xFF;
								getCRC(ret, 3+nlen+2, 0, 3+nlen, &hi, &lo);
								ret[3+nlen]=hi;
								ret[3+nlen+1]=lo;

								if(useRTS) 
								{
									digitalWrite(pinRTS, VSET);
									delay(pDelay);
								}
								ser->write(ret, 3+nlen+2);
								if(useRTS) 
								{
									delay(nDelay);
									digitalWrite(pinRTS, VRESET);
								}

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 5:		//BitWrite
						if(ResCnt >= 8)
						{
							unsigned short Data = (lstResponse[4] << 8) | lstResponse[5];
							byte hi = 0xFF, lo = 0xFF;
							getCRC(lstResponse,_ListSize, 0, 6, &hi, &lo);
							ModbusRTUSlaveBitAddress *a = getBitAddress(Address);
							if (a != NULL && lstResponse[6] == hi && lstResponse[7] == lo)
							{
								unsigned short stidx = (Address - a->addr) / 8;

								bitWrite(a->values[stidx], (Address - a->addr)%8, Data==0xFF00);

								if(!(useBroadcast && Slave == 0))
								{
									byte ret[8];
									ret[0]=Slave;	
									ret[1]=Function;	
									ret[2]=((Address&0xFF00)>>8);
									ret[3]=((Address&0x00FF));
									ret[4]=((Data&0xFF00)>>8);
									ret[5]=((Data&0x00FF));
									byte hi = 0xFF, lo = 0xFF;
									getCRC(ret, 8, 0, 6, &hi, &lo);
									ret[6]=hi;
									ret[7]=lo;
									ser->write(ret, 8);
									
									if(useRTS) 
									{
										digitalWrite(pinRTS, VSET);
										delay(pDelay);
									}
									ser->write(ret, 8);
									if(useRTS) 
									{
										delay(nDelay);
										digitalWrite(pinRTS, VRESET);
									}
								}

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 6:		//WordWrite
						if(ResCnt >= 8)
						{
							unsigned short Data = (lstResponse[4] << 8) | lstResponse[5];
							byte hi = 0xFF, lo = 0xFF;
							getCRC(lstResponse,_ListSize, 0, 6, &hi, &lo);
							ModbusRTUSlaveWordAddress *a = getWordAddress(Address);
							if (a != NULL && lstResponse[6] == hi && lstResponse[7] == lo)
							{
								unsigned short stidx = Address - a->addr;

								a->values[stidx] = Data;

								if(!(useBroadcast && Slave == 0))
								{
									byte ret[8];
									ret[0]=Slave;	
									ret[1]=Function;	
									ret[2]=((Address&0xFF00)>>8);
									ret[3]=((Address&0x00FF));
									ret[4]=((Data&0xFF00)>>8);
									ret[5]=((Data&0x00FF));
									byte hi = 0xFF, lo = 0xFF;
									getCRC(ret, 8, 0, 6, &hi, &lo);
									ret[6]=hi;
									ret[7]=lo;
									if(useRTS) 
									{
										digitalWrite(pinRTS, VSET);
										delay(pDelay);
									}
									ser->write(ret, 8);
									if(useRTS) 
									{
										delay(nDelay);
										digitalWrite(pinRTS, VRESET);
									}
								}

								ResCnt=0;
							}
							else bvalid = false;
						}
						break;
					case 15:	//MultiBitWrite
						if(ResCnt >= 7)
						{
							unsigned short Length = (lstResponse[4] << 8) | lstResponse[5];
							byte ByteCount = lstResponse[6];
							if(ResCnt >= 9+ByteCount)
							{
								byte hi = 0xFF, lo = 0xFF;
								getCRC(lstResponse,_ListSize, 0, 7 + ByteCount, &hi, &lo);
								if(lstResponse[(9 + ByteCount - 2)] == hi && lstResponse[(9 + ByteCount - 1)] == lo)
								{
									ModbusRTUSlaveBitAddress *a = getBitAddress(Address, Length);
									if (a != NULL) 
									{
										unsigned short stidx = (Address - a->addr) / 8;
										int ng=(Address - a->addr) % 8;
										int ns=stidx;

										for(int i=7; i<7+ByteCount;i++)
										{
											byte val = lstResponse[i];
											for(int j=0;j<8;j++)
											{
												bitWrite(a->values[ns], ng++, bitRead(val,j));
												if(ng==8){ns++;ng=0;}
											}
										}

										if(bvalid)
										{
											if(!(useBroadcast && Slave == 0))
											{
												byte ret[8];
												ret[0]=Slave;	
												ret[1]=Function;	
												ret[2]=((Address&0xFF00)>>8);
												ret[3]=((Address&0x00FF));
												ret[4]=((Length&0xFF00)>>8);
												ret[5]=((Length&0x00FF));
												byte hi = 0xFF, lo = 0xFF;
												getCRC(ret, 8, 0, 6, &hi, &lo);
												ret[6]=hi;
												ret[7]=lo;
												if(useRTS) 
												{
													digitalWrite(pinRTS, VSET);
													delay(pDelay);
												}
												ser->write(ret, 8);
												if(useRTS) 
												{
													delay(nDelay);
													digitalWrite(pinRTS, VRESET);
												}
											}
											ResCnt=0;
										}
									}
									else bvalid=false;
								}
								else bvalid=false;
							}
						}
						break; 
					case 16:	//MultiWordWrite
						if(ResCnt >= 7)
						{
							unsigned short Length = (lstResponse[4] << 8) | lstResponse[5];
							byte ByteCount = lstResponse[6];
							if(ResCnt >= 9+ByteCount)
							{
								byte hi = 0xFF, lo = 0xFF;
								getCRC(lstResponse,_ListSize, 0, 7 + ByteCount, &hi, &lo);
								if(lstResponse[(9 + ByteCount - 2)] == hi && lstResponse[(9 + ByteCount - 1)] == lo)
								{
									ModbusRTUSlaveWordAddress *a = getWordAddress(Address);
									if(a != NULL)
									{	
										for(int i=7; i<7+ByteCount;i+=2)
										{
											unsigned short data = lstResponse[i] << 8 | lstResponse[i+1];
											if ((Address + ((i-7)/2)) - a->addr < a->len) 
												a->values[(Address + ((i-7)/2)) - a->addr] = data;	
											else { bvalid=false; break; }
										}
										if(bvalid)
										{
											if(!(useBroadcast && Slave == 0))
											{
												byte ret[8];
												ret[0]=Slave;	
												ret[1]=Function;	
												ret[2]=((Address&0xFF00)>>8);
												ret[3]=((Address&0x00FF));
												ret[4]=((Length&0xFF00)>>8);
												ret[5]=((Length&0x00FF));
												byte hi = 0xFF, lo = 0xFF;
												getCRC(ret, 8, 0, 6, &hi, &lo);
												ret[6]=hi;
												ret[7]=lo;
												if(useRTS) 
												{
													digitalWrite(pinRTS, VSET);
													delay(pDelay);
												}
												ser->write(ret, 8);
												if(useRTS) 
												{
													delay(nDelay);
													digitalWrite(pinRTS, VRESET);
												}
											}
											ResCnt=0;
										}
									}
									else bvalid=false;
								}
								else bvalid=false;
							}
						}
						break;
					case 26:		//WordBitSet
						if(ResCnt >= 9)
						{
							unsigned short Data = (lstResponse[5] << 8) | lstResponse[6];
							byte hi = 0xFF, lo = 0xFF;
							getCRC(lstResponse,_ListSize, 0, 7, &hi, &lo);
							ModbusRTUSlaveWordAddress *a = getWordAddress(Address);
							if (a != NULL && lstResponse[7] == hi && lstResponse[8] == lo)
							{
								unsigned short stidx = Address - a->addr;
								unsigned short bitidx = lstResponse[4];

								if(bitidx >= 0 && bitidx < 16)
								{
									bitWrite(a->values[stidx], bitidx, Data==0xFF00);

									if(!(useBroadcast && Slave == 0))
									{
										byte ret[8];
										ret[0]=Slave;	
										ret[1]=Function;	
										ret[2]=((Address&0xFF00)>>8);
										ret[3]=((Address&0x00FF));
										ret[4]=((a->values[stidx]&0xFF00)>>8);
										ret[5]=((a->values[stidx]&0x00FF));
										byte hi = 0xFF, lo = 0xFF;
										getCRC(ret, 8, 0, 6, &hi, &lo);
										ret[6]=hi;
										ret[7]=lo;
										if(useRTS) 
										{
											digitalWrite(pinRTS, VSET);
											delay(pDelay);
										}
										ser->write(ret, 8);
										if(useRTS) 
										{
											delay(nDelay);
											digitalWrite(pinRTS, VRESET);
										}
									}
									ResCnt=0;
								}
								else bvalid = false;
							}
							else bvalid = false;
						}
						break;
				}
			}
			else bvalid = false;
		}
		lastrecv = millis();
	}
	if(!bvalid && ResCnt>0) ResCnt=0;
	if(ResCnt>0 && (millis()-lastrecv > 50 || millis() < lastrecv)) ResCnt=0;
}

void ModbusRTUSlave::getCRC(byte* pby, int arsize, int startindex, int nSize, byte* byFirstReturn, byte* bySecondReturn)
{
	int uIndex;
	byte uchCRCHi = 0xff;
	byte uchCRCLo = 0xff;
	for (int i = startindex; i < startindex + nSize && i<arsize; i++)
	{
		uIndex = uchCRCHi ^ pby[i];
		uchCRCHi = uchCRCLo ^ auchCRCHi[uIndex];
		uchCRCLo = auchCRCLo[uIndex];
	}
	(*byFirstReturn) = uchCRCHi;
	(*bySecondReturn) = uchCRCLo;
}

ModbusRTUSlaveBitAddress::ModbusRTUSlaveBitAddress(unsigned short Address, byte* value, int cnt)
{
	addr = Address;
	values = value;
	len = cnt;
}

ModbusRTUSlaveWordAddress::ModbusRTUSlaveWordAddress(unsigned short Address, unsigned short* value, int cnt)
{
	addr = Address;
	values = value;
	len = cnt;
}
