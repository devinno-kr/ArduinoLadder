#include <Arduino.h>

#define DLE 0x10
#define STX 0x02
#define ETX 0x03

class TextCommRTUSlave
{
    public:
        TextCommRTUSlave() 
        {
            bufSize         = 512;
            buf             = (byte*)malloc(bufSize);
            user_onReceive  = NULL;
        }
        TextCommRTUSlave(long bufferSize)
        {
            bufSize         = bufferSize;
            buf             = (byte*)malloc(bufSize);
            user_onReceive  = NULL;
        }
        
        void begin(HardwareSerial&  serial, long baudrate, byte slaveAddr)
        {
			slave   = slaveAddr;
			ser     = &serial;
            resCnt  = 0;
            bDLE    = false;
            ser->begin(baudrate);
        }

        void end()
        {
            ser->end();
        }

        void loop()
        {
            while(ser->available())
            {
                byte d = ser->read();
                byte v = d;
                if(bDLE) 
                {  
                    bDLE = false; 
                    if(v >= DLE) v -= DLE;   
                    else bValid = false;
                }
                switch(d)
                {
                    case STX:   resCnt = 0;         bValid = true;  break;
                    case ETX:   analyzePacket();                    break;
                    case DLE:   bDLE = true;                        break;
                    default:    buf[resCnt++] = v;                  break;
                }
            }
        }

        void onReceive(void (*func)(int, char*, long) )
        {
            user_onReceive = func;
        }

		void writeContent(char* text, long len)
		{
			for(long i=0; i<len; i++)
			{
				byte d = text[i];
				if(d==STX || d==ETX || d==DLE)
				{
					ser->write(DLE);
					ser->write(DLE+d);
					tsum += d;
				}
				else 
				{	
					ser->write(d);
					tsum += d;
				}
			}	
		}

		void writeStart(byte cmd)
		{
			ser->write(STX);
			writebyte(slave);    
			writebyte(cmd); 
			tsum = slave + cmd;
		}

		void writeEnd()
		{
			writebyte(tsum);
			ser->write(ETX);
			ser->flush();
		}

    private:
        long resCnt = 0;
        HardwareSerial* ser;  
        byte* buf;
        long bufSize;
        byte slave;
        bool bDLE = false, bValid = false;
        byte tsum=0;
        void (*user_onReceive)(int, char*, long);

		void writebyte(byte d)
		{
			if(d==STX || d==ETX || d==DLE)
			{
				ser->write(DLE);
				ser->write(DLE+d);
			}
			else 
			{	
				ser->write(d);
			}
		}

        void analyzePacket()
        {
            if(bValid)
            {
                if(resCnt >= 3 && buf[0] == slave)
                {
                    byte sum = 0;
                    for(int i = 0; i < resCnt-1; i++) sum += buf[i];
                    if(sum == buf[resCnt -1])
                    {
                        byte cmd = buf[1];

                        char msg[resCnt-3+1];
                        memcpy(msg, buf+2, resCnt-3);
                        msg[resCnt-3] = 0;
                        
                        if(user_onReceive != NULL) 
                        {
                            user_onReceive(cmd, msg, resCnt-3+1);
                        }
                    }
                }
            }
        }
};
