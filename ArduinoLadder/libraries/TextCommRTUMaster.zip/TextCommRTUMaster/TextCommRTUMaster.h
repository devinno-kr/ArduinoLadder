#include <Arduino.h>

#define DLE 0x10
#define STX 0x02
#define ETX 0x03

class TextCommRTUMaster
{
    public :
        TextCommRTUMaster() 
        {
            bufSize         = 512;
            buf             = (byte*)malloc(bufSize);
        }
        TextCommRTUMaster(long bufferSize)
        {
            bufSize         = bufferSize;
            buf             = (byte*)malloc(bufSize);
        }
        
        void begin(HardwareSerial&  serial, long baudrate)
        {
            ser     = &serial;
            ser->begin(baudrate);
        }

        void end()
        {
            ser->end();
        }

		void setTimeout(int timeout)
		{
			this->timeout=timeout;
		}

        bool SendRecv(byte id, byte cmd, char* sendbuf, char* recvbuf, int len)
        {
            bool ret=false;
			
			while(ser->available()) ser->read();

            sendMessage(id, cmd, sendbuf);

            unsigned long prev = millis();
            unsigned long gap=0;
            bool bCollecting = true;
            bool bDLE = false, bValid = true;
            long resCnt = 0;

            while (bCollecting)
            {
                while(ser->available())
                {
                    byte d = ser->read();
                    byte v = d;
                    if (bDLE)
                    {
                        bDLE = false; 
                        if (v >= DLE) v -= DLE;
                        else bValid = false;
                    }

                    switch (d)
                    {
                        case STX: resCnt=0; bValid = true; break;
                        case ETX: bCollecting = false; break;
                        case DLE: bDLE = true; break;
                        default: 
                            if(resCnt<bufSize) buf[resCnt++] = v; 
                            else bValid = false;
                            break;
                    }
                }
                gap = millis() - prev;
                if (gap >= timeout) break;
                if (!bCollecting) break;
                if (!bValid) break;
            }

            if (gap < timeout && bValid && !bCollecting)
            {
                byte sum = 0;
                for(int i = 0; i < resCnt-1; i++) sum += buf[i];
                if(sum == buf[resCnt -1])
                {
                    byte _slave = buf[0];
                    byte _cmd = buf[1];
                    
                    memcpy(recvbuf, buf+2, resCnt-3);
                    recvbuf[resCnt-3] = 0;

                    ret = true;
                }
            }

            return ret;
        }

    private :
        byte* buf;
        long bufSize;
        int timeout = 200;
        HardwareSerial* ser;  
       
        void writebyte(byte d)
        {
            if(d==STX || d==ETX || d==DLE)
            {
                ser->write(DLE);
                ser->write(DLE + d);
            }
            else ser->write(d);
        }
        
        void sendMessage(byte id, byte cmd, char* msg)
        {
            if(msg != NULL)
            {
                byte sum = id + cmd;
                for(int i=0; i < strlen(msg); i++) sum += msg[i];
                ser->write(STX);
                writebyte(id);
                writebyte(cmd);
                for(int i=0; i < strlen(msg); i++) writebyte((byte)msg[i]);
                writebyte(sum);
                ser->write(ETX);
				ser->flush();
            }
            else
            {
                ser->write(STX);
                writebyte(id);
                writebyte(cmd);
                writebyte(id + cmd);
                ser->write(ETX);
	            ser->flush();
            }
        }

};
